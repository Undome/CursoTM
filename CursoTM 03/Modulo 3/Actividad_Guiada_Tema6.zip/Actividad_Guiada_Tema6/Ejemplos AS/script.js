// Make a GET request to retrieve data from an API
// fetch('https://63c46ee4a908563575371e15.mockapi.io/users/90', {method: 'GET'})
//   .then(response => response.json())
//   .then(data => console.log(data))
//   .catch(error => console.error(error));

  // Make a POST request to create a new resource in the API
// fetch('https://63c46ee4a908563575371e15.mockapi.io/users', {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({ createdAt: "01-01-2023", name: 'Curso de Jueves por la noche', avatar:"https://fakeimg.pl/350x200/?text=MAUI" })
//   })
//     .then(response => response.json())
//     .then(data => console.log(data))
//     .catch(error => console.error(error));

    // Make a PUT request to update an existing resource in the API
// fetch('https://63c46ee4a908563575371e15.mockapi.io/users/101', {
//     method: 'PUT',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({ name: 'Noche de Jueves' })
//   })
//     .then(response => response.json())
//     .then(data => console.log(data))
//     .catch(error => console.error(error));

    // Make a DELETE request to delete an existing resource from the API
// fetch('https://63c46ee4a908563575371e15.mockapi.io/users/101', {
//     method: 'DELETE',
//     headers: { 'Content-Type': 'application/json' }
//   })
//     .then(response => response.json())
//     .then(data => console.log(data))
//     .catch(error => console.error(error));
  