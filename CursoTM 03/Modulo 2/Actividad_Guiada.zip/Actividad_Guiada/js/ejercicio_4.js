var persona = {
    nombre: [''],
    apellido: [''],
    edad: 0,
}

var expreg = new RegExp(/^[A-Za-zÑñÁáÉéÍíÓóÚúÜü\s]+$/);

let manejador = {
    set: function(obj, prop, value){
        if(prop === 'edad'){
            if(!Number.isInteger(value)){
                throw new TypeError('La edad no es un entero');
            }
            if(value > 100){
                throw new TypeError('La edad es invalida');
            }
        }
       
        if(!obj.hasOwnProperty(prop)){
            throw new TypeError('La propiedad no existe en el objeto persona');
        }

        if(prop === 'nombre'){
            if(!expreg.test(value)){
                throw new TypeError('En nombre solo se aceptan letras y espacios');
            }
        }
        if(prop === 'apellido'){
            if(!expreg.test(value)){
                throw new TypeError('En apellido solo se aceptan letras y espacios');
            }
        }       

        obj[prop] = value;
        return true;
    }
}

const miProxy = new Proxy(persona, manejador);
miProxy.edad = 35;
miProxy.nombre = "Juan";
miProxy.apellido = "Perez";
miProxy.Twitter = "jkjk";
console.log(miProxy);