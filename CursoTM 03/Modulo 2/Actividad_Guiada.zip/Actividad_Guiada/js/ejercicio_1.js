function quitarDuplicado(arr){
    if(typeof arr == (typeof undefined)){
        console.log("no ingresaste un arreglo");
        return 0;

    }
    if(!(arr instanceof Array)){
        console.log("El valor que ingresaste no es un arreglo");
        return 0;

    }
    if(arr.length==0){
        console.log("El arreglo está vacío");
        return 0;
        
    }
    if(arr.length==1){
        console.log("El arreglo al menos debe de tener 2 elementos");
        return 0;        
    }

    // var result = arr.filter((valor, indice) => {
    //     return arr.indexOf(valor) === indice;
    // })
    // return result;

    //Set
    return [...new Set(arr)];
}

    quitarDuplicado();
    quitarDuplicado({});
    quitarDuplicado([]);
    quitarDuplicado([2]);
    console.log(quitarDuplicado(["10","X","X","2","2","10",10,true, true]));

